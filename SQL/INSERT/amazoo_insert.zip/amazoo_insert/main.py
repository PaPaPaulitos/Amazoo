from model.fornecedor import Fornecedor
from model.produto import *
from controller.connection_factory import cursor, conexao
from controller.insert_produtos import introduzir_produtos
from controller.insert_pessoas import introduzir_pessoas
import climage
from design import *

output = climage.convert("./dog.webp")
print(output)

print(cores['vermelho'])
print(amazoo_texto)
print(cores['verde'])
print(quantos_produtos)
print(cores['ciano'])
produtos =  int(input(cursor))
print(cores['verde'])
print(quantas_pessoas)
print(cores['ciano'])
pessoas =  int(input(cursor))
print(cores['amarelo'])
introduzir_produtos(produtos)
introduzir_pessoas(pessoas)
print(cores['magenta'])
print(conclusao)
print(cores['corOriginal'])


conexao.close()
