class Venda:
        def __init__(self):
                self.carrinho = 1
                self.entrega = 1