cores = {'vermelho': '\033[31m',
        'verde': '\033[32m',
        'azul' : '\033[34m' ,
        'ciano': '\033[36m',
        'magenta': '\033[35m',
        'amarelo': '\033[33m',
        'preto': '\033[30m',
        'branco': '\033[37m',
        'corOriginal':'\033[0;0m'
}


amazoo_texto = "AMAZOO INSERT GENERATOR \n \n"

amazoo_texto = amazoo_texto.center(80)

quantos_produtos = "Digite quantos produtos você quer na loja \n"

quantas_pessoas = "Digite quantos pessoas você quer na loja \n"

cursor = "<amazoo\>"

conclusao = "Todo mundo foi introduzido :) \n"

conclusao = conclusao.center(80)

